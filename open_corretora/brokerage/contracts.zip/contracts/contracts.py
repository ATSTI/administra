# -*- coding: utf-8 -*-
##############################################################################
#
# OpenERP, Open Source Management Solution
# Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from osv import fields,osv

class finance_fond(osv.Model):
 """(NULL)"""
 _name = 'finance.fond'
 _columns = {
 'name': fields.char("Name", size=128, required=True),
 'description': fields.text("Description"),
 'isin': fields.char("Code ISIN", size=64),
 'valeurs': fields.one2many("finance.fond.historique", "fond_id", "Valeurs"),
 }
finance_fond()

class finance_fond_historique(osv.Model):
 """(NULL)"""
 _name = 'finance.fond.historique'
 _columns = {
 'date': fields.date("Date de valeur", required=True),
 'valeur': fields.float("Valeur", required=True),
 'fond_id': fields.many2one("finance.fond", "Fond", required=True),
 '_defaults': fields.({ "sequence": 10    }),
 '_order': fields.("sequence"),
 }
finance_fond_historique()

class finance_contract_type(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.type'
 _columns = {
 'name': fields.char('Nom', size=64),
 'birthdate_req': fields.boolean('Date de naissance requise'),
 'adherent_req': fields.boolean(u'Adhérent requis'),
 'fond_req': fields.boolean('Fonds requis'),
 'secu_req': fields.boolean('Secu requis'),
 'bene_req': fields.boolean('Beneficiaires requis'),
 'contract_ids': fields.one2many('finance.contract.model', 'type_id', 'Produits'),
 'multiple_vers': fields.boolean("Accepte des versements multiples"),
 }
 def write(self, cr, uid, ids, vals, context) :
 # returns 
finance_contract_type()

class finance_fond(osv.Model):
 """(NULL)"""
 _name = 'finance.fond'
 _columns = {
 'name': fields.char("Name", size=128, required=True),
 'description': fields.text("Description"),
 'isin': fields.char("Code ISIN", size=64),
 'valeurs': fields.one2many("finance.fond.historique", "fond_id", "Valeurs"),
 }
finance_fond()

class finance_fond_historique(osv.Model):
 """(NULL)"""
 _name = 'finance.fond.historique'
 _columns = {
 'date': fields.date("Date de valeur", required=True),
 'valeur': fields.float("Valeur", required=True),
 'fond_id': fields.many2one("finance.fond", "Fond", required=True),
 '_defaults': fields.({ "sequence": 10    }),
 '_order': fields.("sequence"),
 }
finance_fond_historique()

class finance_contract_type(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.type'
 _columns = {
 'name': fields.char('Nom', size=64),
 'birthdate_req': fields.boolean('Date de naissance requise'),
 'adherent_req': fields.boolean(u'Adhérent requis'),
 'fond_req': fields.boolean('Fonds requis'),
 'secu_req': fields.boolean('Secu requis'),
 'bene_req': fields.boolean('Beneficiaires requis'),
 'contract_ids': fields.one2many('finance.contract.model', 'type_id', 'Produits'),
 'multiple_vers': fields.boolean("Accepte des versements multiples"),
 }
 def write(self, cr, uid, ids, vals, context) :
 # returns 
finance_contract_type()

class finance_fond(osv.Model):
 """(NULL)"""
 _name = 'finance.fond'
 _columns = {
 'name': fields.char("Name", size=128, required=True),
 'description': fields.text("Description"),
 'isin': fields.char("Code ISIN", size=64),
 'valeurs': fields.one2many("finance.fond.historique", "fond_id", "Valeurs"),
 }
finance_fond()

class finance_fond_historique(osv.Model):
 """(NULL)"""
 _name = 'finance.fond.historique'
 _columns = {
 'date': fields.date("Date de valeur", required=True),
 'valeur': fields.float("Valeur", required=True),
 'fond_id': fields.many2one("finance.fond", "Fond", required=True),
 '_defaults': fields.({ "sequence": 10    }),
 '_order': fields.("sequence"),
 }
finance_fond_historique()

class finance_contract_type(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.type'
 _columns = {
 'name': fields.char('Nom', size=64),
 'birthdate_req': fields.boolean('Date de naissance requise'),
 'adherent_req': fields.boolean(u'Adhérent requis'),
 'fond_req': fields.boolean('Fonds requis'),
 'secu_req': fields.boolean('Secu requis'),
 'bene_req': fields.boolean('Beneficiaires requis'),
 'contract_ids': fields.one2many('finance.contract.model', 'type_id', 'Produits'),
 'multiple_vers': fields.boolean("Accepte des versements multiples"),
 }
 def write(self, cr, uid, ids, vals, context) :
 # returns 
finance_contract_type()

class finance_fond(osv.Model):
 """(NULL)"""
 _name = 'finance.fond'
 _columns = {
 'name': fields.char("Name", size=128, required=True),
 'description': fields.text("Description"),
 'isin': fields.char("Code ISIN", size=64),
 'valeurs': fields.one2many("finance.fond.historique", "fond_id", "Valeurs"),
 }
finance_fond()

class finance_fond_historique(osv.Model):
 """(NULL)"""
 _name = 'finance.fond.historique'
 _columns = {
 'date': fields.date("Date de valeur", required=True),
 'valeur': fields.float("Valeur", required=True),
 'fond_id': fields.many2one("finance.fond", "Fond", required=True),
 '_defaults': fields.({ "sequence": 10    }),
 '_order': fields.("sequence"),
 }
finance_fond_historique()

class finance_contract_type(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.type'
 _columns = {
 'name': fields.char('Nom', size=64),
 'birthdate_req': fields.boolean('Date de naissance requise'),
 'adherent_req': fields.boolean(u'Adhérent requis'),
 'fond_req': fields.boolean('Fonds requis'),
 'secu_req': fields.boolean('Secu requis'),
 'bene_req': fields.boolean('Beneficiaires requis'),
 'contract_ids': fields.one2many('finance.contract.model', 'type_id', 'Produits'),
 'multiple_vers': fields.boolean("Accepte des versements multiples"),
 }
 def write(self, cr, uid, ids, vals, context) :
 # returns 
finance_contract_type()

class finance_contract_risk(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.risk'
 _columns = {
 'name': fields.char('Nom', size=128, required="1"),
 'description': fields.text('Description'),
 'model_id': fields.many2one('finance.contract.model', u'Produit lié', required="1"),
 }
finance_contract_risk()

class finance_fond(osv.Model):
 """(NULL)"""
 _name = 'finance.fond'
 _columns = {
 'name': fields.char("Name", size=128, required=True),
 'description': fields.text("Description"),
 'isin': fields.char("Code ISIN", size=64),
 'valeurs': fields.one2many("finance.fond.historique", "fond_id", "Valeurs"),
 }
finance_fond()

class finance_fond_historique(osv.Model):
 """(NULL)"""
 _name = 'finance.fond.historique'
 _columns = {
 'date': fields.date("Date de valeur", required=True),
 'valeur': fields.float("Valeur", required=True),
 'fond_id': fields.many2one("finance.fond", "Fond", required=True),
 '_defaults': fields.({ "sequence": 10    }),
 '_order': fields.("sequence"),
 }
finance_fond_historique()

class finance_contract_type(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.type'
 _columns = {
 'name': fields.char('Nom', size=64),
 'birthdate_req': fields.boolean('Date de naissance requise'),
 'adherent_req': fields.boolean(u'Adhérent requis'),
 'fond_req': fields.boolean('Fonds requis'),
 'secu_req': fields.boolean('Secu requis'),
 'bene_req': fields.boolean('Beneficiaires requis'),
 'contract_ids': fields.one2many('finance.contract.model', 'type_id', 'Produits'),
 'multiple_vers': fields.boolean("Accepte des versements multiples"),
 }
 def write(self, cr, uid, ids, vals, context) :
 # returns 
finance_contract_type()

class finance_contract_risk(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.risk'
 _columns = {
 'name': fields.char('Nom', size=128, required="1"),
 'description': fields.text('Description'),
 'model_id': fields.many2one('finance.contract.model', u'Produit lié', required="1"),
 }
finance_contract_risk()

class mail_thread(osv.Model):
 """(NULL)"""
 _name = 'mail.thread'
 _columns = {
 }
mail_thread()

class finance_contract_model(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.model'
 _inherit = 'mail.thread'
 _columns = {
 'name': fields.char('Nom', required=True),
 'company_id': fields.many2one('res.partner', 'Compagnie', required=True),
 'supplier_id': fields.many2one('res.partner', 'Fournisseur', required=True),
 'risk_ids': fields.one2many('finance.contract.risk', 'model_id', 'Risques liés'),
 'type_id': fields.many2one('finance.contract.type', 'Type de produit', required=True),
 'description': fields.text('Description'),
 'sale_des': fields.text('Instructions de vente'),
 'multiple_vers': fields.boolean("Accepte des versements multiples"),
 'show_vers_message': fields.boolean("Show message"),
 }
 def onchange_type_id(self, cr, uid, ids, type_id, context) :
 # returns 
 def onchange_vers(self, cr, uid, ids, vers, type_id, context) :
 # returns 
finance_contract_model()

class finance_fond(osv.Model):
 """(NULL)"""
 _name = 'finance.fond'
 _columns = {
 'name': fields.char("Name", size=128, required=True),
 'description': fields.text("Description"),
 'isin': fields.char("Code ISIN", size=64),
 'valeurs': fields.one2many("finance.fond.historique", "fond_id", "Valeurs"),
 }
finance_fond()

class finance_fond_historique(osv.Model):
 """(NULL)"""
 _name = 'finance.fond.historique'
 _columns = {
 'date': fields.date("Date de valeur", required=True),
 'valeur': fields.float("Valeur", required=True),
 'fond_id': fields.many2one("finance.fond", "Fond", required=True),
 '_defaults': fields.({ "sequence": 10    }),
 '_order': fields.("sequence"),
 }
finance_fond_historique()

class finance_contract_type(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.type'
 _columns = {
 'name': fields.char('Nom', size=64),
 'birthdate_req': fields.boolean('Date de naissance requise'),
 'adherent_req': fields.boolean(u'Adhérent requis'),
 'fond_req': fields.boolean('Fonds requis'),
 'secu_req': fields.boolean('Secu requis'),
 'bene_req': fields.boolean('Beneficiaires requis'),
 'contract_ids': fields.one2many('finance.contract.model', 'type_id', 'Produits'),
 'multiple_vers': fields.boolean("Accepte des versements multiples"),
 }
 def write(self, cr, uid, ids, vals, context) :
 # returns 
finance_contract_type()

class finance_contract_risk(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.risk'
 _columns = {
 'name': fields.char('Nom', size=128, required="1"),
 'description': fields.text('Description'),
 'model_id': fields.many2one('finance.contract.model', u'Produit lié', required="1"),
 }
finance_contract_risk()

class mail_thread(osv.Model):
 """(NULL)"""
 _name = 'mail.thread'
 _columns = {
 }
mail_thread()

class finance_contract_model(osv.Model):
 """(NULL)"""
 _name = 'finance.contract.model'
 _inherit = 'mail.thread'
 _columns = {
 'name': fields.char('Nom', required=True),
 'company_id': fields.many2one('res.partner', 'Compagnie', required=True),
 'supplier_id': fields.many2one('res.partner', 'Fournisseur', required=True),
 'risk_ids': fields.one2many('finance.contract.risk', 'model_id', 'Risques liés'),
 'type_id': fields.many2one('finance.contract.type', 'Type de produit', required=True),
 'description': fields.text('Description'),
 'sale_des': fields.text('Instructions de vente'),
 'multiple_vers': fields.boolean("Accepte des versements multiples"),
 'show_vers_message': fields.boolean("Show message"),
 }
 def onchange_type_id(self, cr, uid, ids, type_id, context) :
 # returns 
 def onchange_vers(self, cr, uid, ids, vers, type_id, context) :
 # returns 
finance_contract_model()

class ir_needaction_mixin(osv.Model):
 """(NULL)"""
 _name = 'ir.needaction_mixin'
 _columns = {
 }
ir_needaction_mixin()

